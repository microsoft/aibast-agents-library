---
name: consent-aware-recovery-campaign-draft
description: Gives a Digital Marketing Lead a proposed recovery sequence without sending or scheduling outreach.
---
# Consent-aware recovery campaign draft

Show the fixed draft channels, review timing, neutral subject concepts, consent
gate, and benchmark assumptions. Avoid urgency pressure and availability claims.
Do not send, schedule, deploy, retarget, or create an offer.

---
name: release-risk-review
description: "Use when an analyst asks whether a large or unusual payment is safe to release; shows screening, risk score, and drivers while the analyst decides."
---
# Pre-release risk review

Use when an analyst asks whether a large or unusual payment is safe to release; shows screening, risk score, and drivers while the analyst decides.

## Procedure

1. Use only the uploaded synthetic records and rules.
2. Lead with the specific evidence that answers the persona's question.
3. Keep the figures, identifiers, and tables exactly as recorded for case `PO-04`.
4. Explain uncertainty, prerequisites, and the authorized review needed next.
5. State that the result is synthetic decision support and that no external action occurred.

## Deterministic pilot evidence

- `Risk band`
- `8.9 times`
- `Watchlist screening`

## Safety gate

Do not claim to have changed a system, contacted a person or supplier, made a decision, or completed a transaction. Stop at a reviewable brief or draft.

---
name: payment-status
description: "Use when someone asks where a payment is; returns the stage timeline, expected settlement, and a draft reply that is not sent."
---
# Payment status answer

Use when someone asks where a payment is; returns the stage timeline, expected settlement, and a draft reply that is not sent.

## Procedure

1. Use only the uploaded synthetic records and rules.
2. Lead with the specific evidence that answers the persona's question.
3. Keep the figures, identifiers, and tables exactly as recorded for case `PO-06`.
4. Explain uncertainty, prerequisites, and the authorized review needed next.
5. State that the result is synthetic decision support and that no external action occurred.

## Deterministic pilot evidence

- `Scheme acknowledged`
- `15:00`
- `not sent`

## Safety gate

Do not claim to have changed a system, contacted a person or supplier, made a decision, or completed a transaction. Stop at a reviewable brief or draft.

---
name: queue-overview
description: "Use when the payments lead asks what is in today's release queue, how payments are staged, or which payments need attention."
---
# Release queue overview

Use when the payments lead asks what is in today's release queue, how payments are staged, or which payments need attention.

## Procedure

1. Use only the uploaded synthetic records and rules.
2. Lead with the specific evidence that answers the persona's question.
3. Keep the figures, identifiers, and tables exactly as recorded for case `PO-01`.
4. Explain uncertainty, prerequisites, and the authorized review needed next.
5. State that the result is synthetic decision support and that no external action occurred.

## Deterministic pilot evidence

- `Release Queue`
- `PAY-3105`
- `Needs attention`

## Safety gate

Do not claim to have changed a system, contacted a person or supplier, made a decision, or completed a transaction. Stop at a reviewable brief or draft.

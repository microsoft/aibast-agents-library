---
name: build-thesis
description: "Use when someone describes an acquisition thesis and wants it turned into screening criteria and filters."
---
<!-- bic:source=blank -->
# Thesis to screening criteria

Use when someone describes an acquisition thesis and wants it turned into screening criteria and filters.

## Procedure

1. Use only the uploaded synthetic records and rules.
2. Lead with the specific evidence that answers the persona's question.
3. Explain uncertainty, prerequisites, and the authorized review needed next.
4. State that the result is synthetic decision support and that no external action occurred.

## Deterministic pilot evidence

- `TH-2026-014`
- `5 of 8 pass`
- `Cindral Risk Labs`

## Safety gate

Do not claim to have changed a system, contacted a person or supplier, made a decision, or completed a transaction. Stop at a reviewable brief or draft.

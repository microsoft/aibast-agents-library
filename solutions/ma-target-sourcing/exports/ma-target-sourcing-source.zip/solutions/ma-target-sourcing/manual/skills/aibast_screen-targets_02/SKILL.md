---
name: screen-targets
description: "Use when someone wants the screen run and the passing companies ranked with a transparent weighted score."
---
<!-- bic:source=blank -->
# Ranked target longlist

Use when someone wants the screen run and the passing companies ranked with a transparent weighted score.

## Procedure

1. Use only the uploaded synthetic records and rules.
2. Lead with the specific evidence that answers the persona's question.
3. Explain uncertainty, prerequisites, and the authorized review needed next.
4. State that the result is synthetic decision support and that no external action occurred.

## Deterministic pilot evidence

- `Lumenrock Compliance Systems`
- `85.7`
- `79.8`

## Safety gate

Do not claim to have changed a system, contacted a person or supplier, made a decision, or completed a transaction. Stop at a reviewable brief or draft.

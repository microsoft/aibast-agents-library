---
name: coverage-gaps
description: "Use when a sales operations analyst asks something like \"Where are our biggest coverage gaps\""
---
<!-- bic:source=blank -->
# Coverage gaps

Use when a leader asks where the coverage gaps or under-served markets are.

## Procedure

1. Use only the uploaded synthetic records and rules.
2. Lead with the specific evidence that answers the persona's question.
3. Explain uncertainty, prerequisites, and the authorized review needed next.
4. State that the result is synthetic decision support and that no external action occurred.

## Deterministic pilot evidence

- `5 gaps`
- `$81.7M open spend`
- `IT and Engineering`

## Safety gate

Do not claim to have changed a system, contacted a person or supplier, made a decision, or completed a transaction. Stop at a reviewable brief or draft.

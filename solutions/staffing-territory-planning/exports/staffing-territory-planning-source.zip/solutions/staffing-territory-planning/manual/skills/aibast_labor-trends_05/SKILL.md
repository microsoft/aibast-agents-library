---
name: labor-trends
description: "Use when a regional sales director asks something like \"What labor market trends should I plan around\""
---
<!-- bic:source=blank -->
# Labor trends

Use when someone asks about labor market, hiring or wage trends to plan around.

## Procedure

1. Use only the uploaded synthetic records and rules.
2. Lead with the specific evidence that answers the persona's question.
3. Explain uncertainty, prerequisites, and the authorized review needed next.
4. State that the result is synthetic decision support and that no external action occurred.

## Deterministic pilot evidence

- `31 days`
- `+11%`
- `Planning implication`

## Safety gate

Do not claim to have changed a system, contacted a person or supplier, made a decision, or completed a transaction. Stop at a reviewable brief or draft.

---
name: application-review
description: Use for application intake questions in the Loan Origination Assistant synthetic pilot.
---
<!-- bic:source=blank -->
# Application intake

Summarizes the synthetic loan pipeline, product, amount, LTV, owner, and status.

## Procedure

1. Identify the exact fictional record or report scope; do not substitute a different record.
2. Use the synthetic operating snapshot and return the source-backed evidence required by the request.
3. Separate observed evidence, calculated or heuristic output, and proposed next steps.
4. State that the result is not legal, regulatory, insurance, lending, tax, investment, or financial advice.
5. State that no approval, communication, filing, account change, payment, order, transaction, or external action occurred.
6. Name the authorized human review required before action.

## Locked example

Persona: Loan Officer

Prompt: What is in my mortgage pipeline, and which application is still in document review?

Expected synthetic evidence: LA-2025-4002, Document Review.

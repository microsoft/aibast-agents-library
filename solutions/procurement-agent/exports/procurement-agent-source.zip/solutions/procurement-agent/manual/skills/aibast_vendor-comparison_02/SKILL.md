---
name: vendor-comparison
description: Use when a category buyer wants a neutral view of synthetic vendor ratings, terms, and tiers.
---
<!-- bic:source=blank -->
# Vendor evidence comparison

Use when a category buyer wants a neutral view of synthetic vendor ratings, terms, and tiers.

## Procedure

1. Use only the uploaded synthetic records and rules.
2. Lead with the specific evidence that answers the persona's question.
3. Explain uncertainty, prerequisites, and the authorized review needed next.
4. State that the result is synthetic decision support and that no external action occurred.

## Deterministic pilot evidence

- `AWS`
- `Azure`
- `Ratings and terms are comparison evidence`

## Safety gate

Do not claim to have changed a system, contacted a person or supplier, made a decision, or completed a transaction. Stop at a reviewable brief or draft.

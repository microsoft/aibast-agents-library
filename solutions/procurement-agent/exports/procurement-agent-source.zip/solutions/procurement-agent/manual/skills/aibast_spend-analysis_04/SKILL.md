---
name: spend-analysis
description: Use when a finance director asks which synthetic category is over budget or approaching a limit.
---
<!-- bic:source=blank -->
# Spend and budget review

Use when a finance director asks which synthetic category is over budget or approaching a limit.

## Procedure

1. Use only the uploaded synthetic records and rules.
2. Lead with the specific evidence that answers the persona's question.
3. Explain uncertainty, prerequisites, and the authorized review needed next.
4. State that the result is synthetic decision support and that no external action occurred.

## Deterministic pilot evidence

- `Software`
- `$60,000`
- `No purchase order is created`

## Safety gate

Do not claim to have changed a system, contacted a person or supplier, made a decision, or completed a transaction. Stop at a reviewable brief or draft.

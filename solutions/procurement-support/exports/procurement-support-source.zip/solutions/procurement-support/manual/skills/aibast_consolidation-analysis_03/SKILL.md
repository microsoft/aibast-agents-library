---
name: consolidation-analysis
description: Use when a finance director asks whether fragmented facility demand may qualify for structured sourcing review.
---
<!-- bic:source=blank -->
# Demand-consolidation analysis

Use when a finance director asks whether fragmented facility demand may qualify for structured sourcing review.

## Procedure

1. Use only the uploaded synthetic records and rules.
2. Lead with the specific evidence that answers the persona's question.
3. Explain uncertainty, prerequisites, and the authorized review needed next.
4. State that the result is synthetic decision support and that no external action occurred.

## Deterministic pilot evidence

- `Clinical consumables`
- `4`
- `does not recommend a supplier award`

## Safety gate

Do not claim to have changed a system, contacted a person or supplier, made a decision, or completed a transaction. Stop at a reviewable brief or draft.

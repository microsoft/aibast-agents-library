---
name: savings-scan
description: Use when a procurement manager asks which synthetic contracts or forecasts contain reviewable savings signals.
---
<!-- bic:source=blank -->
# Savings-opportunity scan

Use when a procurement manager asks which synthetic contracts or forecasts contain reviewable savings signals.

## Procedure

1. Use only the uploaded synthetic records and rules.
2. Lead with the specific evidence that answers the persona's question.
3. Explain uncertainty, prerequisites, and the authorized review needed next.
4. State that the result is synthetic decision support and that no external action occurred.

## Deterministic pilot evidence

- `DISC-101`
- `DISC-102`
- `not realized savings`

## Safety gate

Do not claim to have changed a system, contacted a person or supplier, made a decision, or completed a transaction. Stop at a reviewable brief or draft.

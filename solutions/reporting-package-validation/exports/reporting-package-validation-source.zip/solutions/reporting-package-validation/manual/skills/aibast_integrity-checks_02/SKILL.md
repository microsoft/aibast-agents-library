---
name: integrity-checks
description: "Use when someone wants completeness, missing-versus-zero, tie-out and formula checks run before the numbers are read."
---
<!-- bic:source=blank -->
# Integrity checks

Use when someone wants completeness, missing-versus-zero, tie-out and formula checks run before the numbers are read.

## Procedure

1. Use only the uploaded synthetic records and rules.
2. Lead with the specific evidence that answers the persona's question.
3. Explain uncertainty, prerequisites, and the authorized review needed next.
4. State that the result is synthetic decision support and that no external action occurred.

## Deterministic pilot evidence

- `2 blocking`
- `Outdoor Forecast`
- `A missing cell is not a zero`

## Safety gate

Do not claim to have changed a system, contacted a person or supplier, made a decision, or completed a transaction. Stop at a reviewable brief or draft.

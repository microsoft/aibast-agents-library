---
name: exception-queue
description: "Use when someone wants the exceptions listed and routed to their owners."
---
<!-- bic:source=blank -->
# Exception routing

Use when someone wants the exceptions listed and routed to their owners.

## Procedure

1. Use only the uploaded synthetic records and rules.
2. Lead with the specific evidence that answers the persona's question.
3. Explain uncertainty, prerequisites, and the authorized review needed next.
4. State that the result is synthetic decision support and that no external action occurred.

## Deterministic pilot evidence

- `EX-01`
- `Consolidation lead`
- `none has been sent`

## Safety gate

Do not claim to have changed a system, contacted a person or supplier, made a decision, or completed a transaction. Stop at a reviewable brief or draft.

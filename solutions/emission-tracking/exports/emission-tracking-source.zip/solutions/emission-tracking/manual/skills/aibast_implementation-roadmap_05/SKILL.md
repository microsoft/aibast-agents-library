---
name: emission-tracking-implementation-roadmap
description: "Use when an Environmental Manager asks for the phased implementation roadmap."
---
# Emissions Tracking Agent: Implementation Roadmap

## Route

Use the `implementation_roadmap` operation. The canonical persona prompt is:

> Create the implementation roadmap for our emissions reductions.

## Procedure

1. Read the synthetic knowledge records and controls.
2. Call or reproduce only the `implementation_roadmap` operation behavior.
3. Lead with source-backed identifiers and evidence.
4. State uncertainty and the required authorized review.
5. End with the operation's no-write boundary.

## Required evidence

- Phase 1 (Next 90 days)
- $810K
- 27% emissions reduction

Never imply that a live system, filing, account, crew, supplier, shipment, emissions claim, or inventory position was changed.

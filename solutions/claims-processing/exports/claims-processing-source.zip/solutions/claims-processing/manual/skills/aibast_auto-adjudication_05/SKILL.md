---
name: auto-adjudication
description: "Use when a claims manager asks something like \"Yes, auto-adjudicate the eligible claims and show me the results\""
---
<!-- bic:source=blank -->
# Auto adjudication

Use when a claims manager asks something like "Yes, auto-adjudicate the eligible claims and show me the results"

## Procedure

1. Use only the uploaded synthetic records and rules.
2. Lead with the specific evidence that answers the persona's question.
3. Explain uncertainty, prerequisites, and the authorized review needed next.
4. State that the result is synthetic decision support and that no external action occurred.

## Deterministic pilot evidence

- `1,724`
- `$290,350`
- `sign-off`

## Safety gate

Do not claim to have changed a system, contacted a person or supplier, made a decision, or completed a transaction. Stop at a reviewable brief or draft.

"""
Ask HR Agent

AI-powered HR assistant for employee self-service: time-off requests,
benefits inquiries, parental leave guidance, and policy lookups.

Where a real deployment would call Workday, Benefits Portal, or HR systems,
this agent uses a synthetic data layer so it runs anywhere without credentials.
"""

import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "..", "templates"))

from basic_agent import BasicAgent

# ═══════════════════════════════════════════════════════════════
# RAPP AGENT MANIFEST
# ═══════════════════════════════════════════════════════════════
__manifest__ = {
    "schema": "rapp-agent/1.0",
    "name": "@aibast-agents-library/ask-hr",
    "version": "1.0.0",
    "display_name": "Ask HR Agent",
    "description": "Provide self-service HR inquiry handling that transforms the process from a manual ticket-based system to intelligent, automated resolutions.",
    "author": "AIBAST",
    "tags": ["hr", "human-resources", "benefits", "time-off", "employee-self-service"],
    "category": "human_resources",
    "quality_tier": "verified",
    "requires_env": [],
    "dependencies": ["@rapp/basic-agent"],
}


# ═══════════════════════════════════════════════════════════════
# SYNTHETIC DATA LAYER
# ═══════════════════════════════════════════════════════════════

_EMPLOYEES = {
    "jordan": {
        "id": "emp-1001", "name": "Jordan Chen", "title": "Senior Product Manager",
        "department": "Product", "manager": "Sarah Johnson", "tenure_years": 3.5,
        "email": "jordan.chen@contoso.com",
        "leave_balance": {
            "vacation": 15.5, "sick": 8.0, "personal": 3.0,
            "accrual_rate": 1.25,
        },
        "health_plan": {
            "plan": "PPO Family Plan", "monthly_premium": 450,
            "deductible_individual": 500, "deductible_family": 1500,
            "oop_max_individual": 3000, "oop_max_family": 6000,
            "dependents": ["Spouse"],
        },
    },
    "michael": {
        "id": "emp-1002", "name": "Michael Torres", "title": "Account Executive",
        "department": "Sales", "manager": "David Kim", "tenure_years": 1.2,
        "email": "michael.torres@contoso.com",
        "leave_balance": {
            "vacation": 10.0, "sick": 6.0, "personal": 2.0,
            "accrual_rate": 1.0,
        },
        "health_plan": {
            "plan": "HMO Individual", "monthly_premium": 220,
            "deductible_individual": 750, "deductible_family": None,
            "oop_max_individual": 4000, "oop_max_family": None,
            "dependents": [],
        },
    },
    "sarah": {
        "id": "emp-1003", "name": "Sarah Williams", "title": "Engineering Lead",
        "department": "Engineering", "manager": "Alex Rivera", "tenure_years": 5.0,
        "email": "sarah.williams@contoso.com",
        "leave_balance": {
            "vacation": 22.0, "sick": 10.0, "personal": 3.0,
            "accrual_rate": 1.5,
        },
        "health_plan": {
            "plan": "PPO Family Plan", "monthly_premium": 450,
            "deductible_individual": 500, "deductible_family": 1500,
            "oop_max_individual": 3000, "oop_max_family": 6000,
            "dependents": ["Spouse", "Child (age 4)"],
        },
    },
}

_COMPANY_HOLIDAYS = [
    {"name": "Memorial Day", "date": "May 26"},
    {"name": "Independence Day", "date": "Jul 4"},
    {"name": "Labor Day", "date": "Sep 1"},
    {"name": "Thanksgiving", "date": "Nov 27-28"},
    {"name": "Year-End", "date": "Dec 24-25, Dec 31-Jan 1"},
]

_POLICIES = {
    "time_off": {
        "min_notice_5plus_days": "2 weeks",
        "holiday_period": "Dec 15 - Jan 5 requires manager pre-approval",
        "rollover_max": 5,
    },
    "parental_leave": {
        "paternity_weeks": 8, "maternity_weeks": 16,
        "min_tenure_years": 1, "stipend": 2000,
        "backup_childcare_months": 6,
    },
    "remote_work": {
        "standard_days_per_week": 3,
        "new_parent_bonus_days": 2,
        "new_parent_bonus_months": 6,
        "core_hours": "10 AM - 3 PM local",
        "equipment_stipend": 1000,
        "internet_reimbursement": 50,
    },
    "health_insurance": {
        "enrollment_window_days": 30,
        "dependent_premium_increase": 125,
        "well_baby_covered": True,
        "pediatric_copay": 20,
        "dependent_life_insurance": 10000,
    },
}

_HR_GATE = (
    "Synthetic policy guidance only. This agent does not determine eligibility, "
    "infer sensitive employee circumstances, submit a transaction, notify a "
    "manager, or make an HR decision."
)


# ═══════════════════════════════════════════════════════════════
# HELPERS
# ═══════════════════════════════════════════════════════════════

def _resolve_employee(query):
    if not query:
        return "jordan"
    q = query.lower().strip()
    for key in _EMPLOYEES:
        if key in q or q in _EMPLOYEES[key]["name"].lower():
            return key
    return "jordan"


def _submit_time_off(emp_key, start_date, end_date, days):
    emp = _EMPLOYEES[emp_key]
    remaining = emp["leave_balance"]["vacation"] - days
    return {
        "employee": emp["name"], "dates": f"{start_date} to {end_date}",
        "days": days, "status": "Draft for employee review",
        "manager": emp["manager"], "balance_after": remaining,
    }


# ═══════════════════════════════════════════════════════════════
# AGENT CLASS
# ═══════════════════════════════════════════════════════════════

class AskHRAgent(BasicAgent):
    """
    Employee self-service HR assistant.

    Operations:
        leave_balance     - check vacation, sick, personal day balances
        submit_time_off   - request time off for given dates
        parental_leave    - parental leave eligibility and benefits
        health_insurance  - health plan details and dependent enrollment
        remote_work       - remote work policy and new-parent flexibility
        benefits_summary  - comprehensive benefits package overview
    """

    def __init__(self):
        self.name = "AskHRAgent"
        self.metadata = {
            "name": self.name,
            "description": (
                f"{__manifest__['description']} Always use this tool for fictional "
                "leave balances, vacation or time-off previews, parental-leave "
                "guidance, health-plan questions, remote-work policy, and benefits "
                "summaries. A request to preview vacation dates or to avoid "
                "submitting anything must use submit_time_off; that operation "
                "returns a deterministic Not Submitted draft and sends no "
                "notification. Use fictional profiles and published policy "
                "examples only. Never infer a sensitive employee circumstance, "
                "decide eligibility, submit a transaction, or make an HR decision."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "operation": {
                        "type": "string",
                        "enum": [
                            "leave_balance", "submit_time_off",
                            "parental_leave", "health_insurance",
                            "remote_work", "benefits_summary",
                        ],
                        "description": (
                            "Choose leave_balance only for available leave and "
                            "notice rules; submit_time_off for any vacation/date "
                            "preview or request, including 'do not submit' wording; "
                            "parental_leave for parental policy; health_insurance "
                            "for plan or enrollment guidance; remote_work for remote "
                            "policy; and benefits_summary for an overall package."
                        ),
                    },
                    "employee_name": {
                        "type": "string",
                        "description": "Employee name (e.g. 'Jordan Chen')",
                    },
                    "start_date": {
                        "type": "string",
                        "description": "Requested start date for a draft time-off preview",
                    },
                    "end_date": {
                        "type": "string",
                        "description": "Requested end date for a draft time-off preview",
                    },
                    "days": {
                        "type": "number",
                        "description": "Requested vacation days for a draft time-off preview",
                    },
                },
                "required": ["operation"],
            },
        }
        super().__init__(name=self.name, metadata=self.metadata)

    def perform(self, **kwargs) -> str:
        op = kwargs.get("operation", "leave_balance")
        key = _resolve_employee(kwargs.get("employee_name", ""))
        dispatch = {
            "leave_balance": self._leave_balance,
            "submit_time_off": self._submit_time_off,
            "parental_leave": self._parental_leave,
            "health_insurance": self._health_insurance,
            "remote_work": self._remote_work,
            "benefits_summary": self._benefits_summary,
        }
        handler = dispatch.get(op)
        if not handler:
            return f"Unknown operation: {op}"
        if op == "submit_time_off":
            return handler(
                key,
                kwargs.get("start_date", "Sep 14, 2026"),
                kwargs.get("end_date", "Sep 18, 2026"),
                kwargs.get("days", 5),
            )
        return handler(key)

    # ── leave_balance ─────────────────────────────────────────
    def _leave_balance(self, key):
        emp = _EMPLOYEES[key]
        lb = emp["leave_balance"]
        pol = _POLICIES["time_off"]
        holidays = "\n".join(f"- {h['name']}: {h['date']}" for h in _COMPANY_HOLIDAYS)
        return (
            f"**Leave Balance: {emp['name']}**\n\n"
            f"| Leave Type | Available |\n|---|---|\n"
            f"| Vacation | {lb['vacation']} days |\n"
            f"| Sick Leave | {lb['sick']} days |\n"
            f"| Personal Days | {lb['personal']} days |\n"
            f"| Accrual Rate | {lb['accrual_rate']} days/month |\n\n"
            f"**Upcoming Company Holidays:**\n{holidays}\n\n"
            f"**Time Off Guidelines:**\n"
            f"- 5+ days: Requires {pol['min_notice_5plus_days']} notice\n"
            f"- {pol['holiday_period']}\n"
            f"- Rollover policy: Max {pol['rollover_max']} days carry to next year\n\n"
            f"{_HR_GATE}\n\n"
            f"Source: [Synthetic HRIS + Policy Snapshot]\nAgents: AskHRAgent"
        )

    # ── submit_time_off ───────────────────────────────────────
    def _submit_time_off(self, key, start_date, end_date, days):
        emp = _EMPLOYEES[key]
        try:
            days = float(days)
        except (TypeError, ValueError):
            days = 5
        req = _submit_time_off(key, start_date, end_date, days)
        return (
            f"**Time Off Request Preview — Not Submitted**\n\n"
            f"| Detail | Information |\n|---|---|\n"
            f"| Employee | {emp['name']} |\n"
            f"| Dates | {req['dates']} ({req['days']:g} days) |\n"
            f"| Status | {req['status']} |\n"
            f"| Manager | {req['manager']} |\n"
            f"| Projected Balance | {req['balance_after']:g} days remaining |\n\n"
            f"Review the dates, balance, local policy, and coverage with an "
            f"authorized HR or manager before submission. No notification was sent.\n\n"
            f"{_HR_GATE}\n\n"
            f"Source: [Synthetic HRIS Snapshot]\nAgents: AskHRAgent"
        )

    # ── parental_leave ────────────────────────────────────────
    def _parental_leave(self, key):
        emp = _EMPLOYEES[key]
        pol = _POLICIES["parental_leave"]
        return (
            f"**Parental Leave Policy Guidance: {emp['name']} (Synthetic Profile)**\n\n"
            f"| Benefit | Details |\n|---|---|\n"
            f"| Paternity Leave | {pol['paternity_weeks']} weeks fully paid |\n"
            f"| Maternity Leave | {pol['maternity_weeks']} weeks fully paid |\n"
            f"| Eligibility Rule | Verify tenure, location, leave type, and qualifying event with HR |\n"
            f"| Family Care Stipend | ${pol['stipend']:,} one-time |\n"
            f"| Backup Childcare | {pol['backup_childcare_months']} months included |\n\n"
            f"**Additional Support:**\n"
            f"- Flexible return-to-work schedule available\n"
            f"- Parent Employee Resource Group\n"
            f"- Lactation room access\n\n"
            f"**Next Step:** Ask an authorized HR reviewer to confirm the applicable "
            f"policy and submission timing. Do not disclose medical or family details here.\n\n"
            f"{_HR_GATE}\n\n"
            f"Source: [Synthetic Benefits Policy Snapshot]\nAgents: AskHRAgent"
        )

    # ── health_insurance ──────────────────────────────────────
    def _health_insurance(self, key):
        emp = _EMPLOYEES[key]
        hp = emp["health_plan"]
        pol = _POLICIES["health_insurance"]
        deps = ", ".join(hp["dependents"]) if hp["dependents"] else "None"
        return (
            f"**Health Insurance: {emp['name']}**\n\n"
            f"| Coverage | Detail |\n|---|---|\n"
            f"| Plan | {hp['plan']} |\n"
            f"| Monthly Premium | ${hp['monthly_premium']:,} (your contribution) |\n"
            f"| Deductible (Individual) | ${hp['deductible_individual']:,} |\n"
            f"| Out-of-Pocket Max | ${hp['oop_max_individual']:,} |\n"
            f"| Current Dependents | {deps} |\n\n"
            f"**Adding a Dependent:**\n"
            f"- Enrollment window: {pol['enrollment_window_days']} days from qualifying event\n"
            f"- Premium increase: +${pol['dependent_premium_increase']}/month\n"
            f"- Coverage effective: Date of qualifying event\n\n"
            f"**New Baby Benefits (100% Covered):**\n"
            f"- Well-baby care visits\n"
            f"- All immunizations\n"
            f"- Pediatric visits: ${pol['pediatric_copay']} copay\n"
            f"- Dependent life insurance: ${pol['dependent_life_insurance']:,} automatic\n\n"
            f"Verify plan rules and enrollment eligibility with the benefits "
            f"administrator before making a selection.\n\n"
            f"{_HR_GATE}\n\n"
            f"Source: [Synthetic Benefits Policy Snapshot]\nAgents: AskHRAgent"
        )

    # ── remote_work ───────────────────────────────────────────
    def _remote_work(self, key):
        emp = _EMPLOYEES[key]
        pol = _POLICIES["remote_work"]
        return (
            f"**Remote Work Policy Guidance: {emp['name']} (Synthetic Profile)**\n\n"
            f"| Benefit | Published Policy Example |\n|---|---|\n"
            f"| Standard Allowance | {pol['standard_days_per_week']} days/week remote |\n"
            f"| Eligibility | Requires role, location, and manager/HR review |\n"
            f"| Core Hours | {pol['core_hours']} |\n\n"
            f"**Home Office Support:**\n"
            f"- Equipment stipend: ${pol['equipment_stipend']:,} one-time\n"
            f"- Internet reimbursement: ${pol['internet_reimbursement']}/month\n"
            f"- Ergonomic assessment: Virtual consultation\n"
            f"- Same-day IT support available\n\n"
            f"Do not infer caregiver, disability, medical, or family status from "
            f"a request. Route exceptions to authorized HR review.\n\n"
            f"{_HR_GATE}\n\n"
            f"Source: [Synthetic HR Policy Snapshot]\nAgents: AskHRAgent"
        )

    # ── benefits_summary ──────────────────────────────────────
    def _benefits_summary(self, key):
        emp = _EMPLOYEES[key]
        lb = emp["leave_balance"]
        hp = emp["health_plan"]
        pol = _POLICIES

        items = []
        items.append(f"- Time Off: {lb['vacation']} vacation days + {lb['sick']} sick days")
        items.append("- Parental Leave: Policy details require HR eligibility review")
        items.append(f"- Health Coverage: {hp['plan']} (${hp['monthly_premium']}/mo)")
        items.append(f"- Remote Work: {pol['remote_work']['standard_days_per_week']} days/week")
        items.append(f"- Equipment Stipend: ${pol['remote_work']['equipment_stipend']:,}")

        return (
            f"**Benefits Summary: {emp['name']} (Synthetic Profile)**\n"
            f"**{emp['title']}, {emp['department']}** ({emp['tenure_years']} years)\n\n"
            f"**Your Benefits Package:**\n"
            + "\n".join(items) + "\n\n"
            f"No salary, medical, family-status, or total-compensation value is inferred.\n\n"
            f"**Next Steps:**\n"
            f"1. Review parental leave form (submit 30 days before due date)\n"
            f"2. Benefits enrollment changes within 30 days of qualifying event\n"
            f"3. Discuss remote schedule through the approved HR process\n\n"
            f"{_HR_GATE}\n\n"
            f"Source: [Synthetic HR Policy Snapshot]\nAgents: AskHRAgent"
        )


if __name__ == "__main__":
    agent = AskHRAgent()
    for op in ["leave_balance", "submit_time_off", "parental_leave",
               "health_insurance", "remote_work", "benefits_summary"]:
        print("=" * 60)
        print(agent.perform(operation=op, employee_name="Jordan Chen"))
        print()

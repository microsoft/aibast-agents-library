---
name: benefits-summary
description: Use when HR operations needs a concise fictional profile summary without estimating compensation or deciding eligibility.
---
<!-- bic:source=blank -->
# Benefits snapshot explanation

Use when HR operations needs a concise fictional profile summary without estimating compensation or deciding eligibility.

## Procedure

1. Use only the uploaded synthetic records and rules.
2. Lead with the specific evidence that answers the persona's question.
3. Explain uncertainty, prerequisites, and the authorized review needed next.
4. State that the result is synthetic decision support and that no external action occurred.

## Deterministic pilot evidence

- `No salary`
- `Total-compensation value is inferred`
- `Synthetic Profile`

## Safety gate

Do not claim to have changed a system, contacted a person or supplier, made a decision, or completed a transaction. Stop at a reviewable brief or draft.

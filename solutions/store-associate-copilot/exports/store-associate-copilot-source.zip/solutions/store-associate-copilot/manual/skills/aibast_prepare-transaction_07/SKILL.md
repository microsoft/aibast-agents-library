---
name: prepare-transaction
description: "Use when a store associate asks something like \"My Gold member customer is taking the TechPro with the warranty and cleaning kit. Get the sale ready\""
---
<!-- bic:source=blank -->
# Prepare transaction

Use when a store associate asks something like "My Gold member customer is taking the TechPro with the warranty and cleaning kit. Get the sale ready"

## Procedure

1. Use only the uploaded synthetic records and rules.
2. Lead with the specific evidence that answers the persona's question.
3. Explain uncertainty, prerequisites, and the authorized review needed next.
4. State that the result is synthetic decision support and that no external action occurred.

## Deterministic pilot evidence

- `Transaction Prepared (Not Rung Up)`
- `$273.12`
- `Payment Options Available`

## Safety gate

Do not claim to have changed a system, contacted a person or supplier, made a decision, or completed a transaction. Stop at a reviewable brief or draft.

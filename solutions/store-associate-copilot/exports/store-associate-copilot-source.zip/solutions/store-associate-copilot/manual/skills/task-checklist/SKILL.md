---
name: store-shift-planning-checklist
description: Helps a Floor Specialist review opening, midday, or closing work without claiming execution.
---
# Store shift planning checklist

List the packaged tasks by priority and estimated time for the requested shift.
Use Floor Specialist language and call the result a plan. Do not claim doors,
alarms, POS, deposits, pickups, inventory, or customer queues were changed.


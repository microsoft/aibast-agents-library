---
name: respectful-customer-assistance-draft
description: Drafts pressure-free language for a Store Associate without sending a message or performing a transaction.
---
# Respectful customer assistance draft

Select the matching synthetic scenario, give short draft language, a respectful
follow-up, and practical tips. Never infer sensitive traits, pressure a shopper,
send anything, apply a promotion, process a return, or transact. Escalate policy
or payment decisions to an authorized associate.

---
name: recommend-resolution
description: "Use when a back-office agent asks something like \"Jennifer Adams was charged $149 for an add-on she never ordered. What should I do to resolve this\""
---
<!-- bic:source=blank -->
# Recommend resolution

Use when a back-office agent asks something like "Jennifer Adams was charged $149 for an add-on she never ordered. What should I do to resolve this"

## Procedure

1. Use only the uploaded synthetic records and rules.
2. Lead with the specific evidence that answers the persona's question.
3. Explain uncertainty, prerequisites, and the authorized review needed next.
4. State that the result is synthetic decision support and that no external action occurred.

## Deterministic pilot evidence

- `Full refund`
- `$50 goodwill`
- `Free month`

## Safety gate

Do not claim to have changed a system, contacted a person or supplier, made a decision, or completed a transaction. Stop at a reviewable brief or draft.

---
name: escalation-routing
description: Use when an escalation manager asks which team and SLA rule apply, without executing the route.
---
<!-- bic:source=blank -->
# Escalation routing review

Use when an escalation manager asks which team and SLA rule apply, without executing the route.

## Procedure

1. Use only the uploaded synthetic records and rules.
2. Lead with the specific evidence that answers the persona's question.
3. Explain uncertainty, prerequisites, and the authorized review needed next.
4. State that the result is synthetic decision support and that no external action occurred.
5. Include the exact sentence `This agent does not execute the escalation.`

## Deterministic pilot evidence

- `INQ-4003`
- `Tier 2 Engineering`
- `2 hours`
- `does not execute`

## Safety gate

Do not claim to have changed a system, contacted a person or supplier, made a decision, or completed a transaction. Stop at a reviewable brief or draft.

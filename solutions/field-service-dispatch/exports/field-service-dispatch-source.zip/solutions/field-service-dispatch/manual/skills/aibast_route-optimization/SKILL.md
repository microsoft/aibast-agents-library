---
name: field-service-dispatch-route-optimization
description: Use when a Service Director asks to compare zone capacity without rerouting.
---
# Field Service Dispatch Agent: Route Optimization

## Route

Use the `route_optimization` operation. The canonical persona prompt is:

> Compare Central zone load and capacity before anyone is rerouted.

## Procedure

1. Read the synthetic knowledge records and controls.
2. Call or reproduce only the `route_optimization` operation behavior.
3. Lead with source-backed identifiers and evidence.
4. State uncertainty and the required authorized review.
5. End with the operation's no-write boundary.

## Required evidence

- Central
- 3
- dispatcher must validate

Never imply that a live system, filing, account, crew, supplier, shipment, emissions claim, or inventory position was changed.

---
name: intake-packet
description: "Use when a patient access representative asks something like \"Which forms go in Sarah Martinez's intake packet, and does it include HIPAA consent and medication history\""
---
<!-- bic:source=blank -->
# Intake packet

Use when a patient access representative asks something like "Which forms go in Sarah Martinez's intake packet, and does it include HIPAA consent and medication history"

## Procedure

1. Use only the uploaded synthetic records and rules.
2. Lead with the specific evidence that answers the persona's question.
3. Explain uncertainty, prerequisites, and the authorized review needed next.
4. State that the result is synthetic decision support and that no external action occurred.

## Deterministic pilot evidence

- `Digital Intake Packet Draft`
- `HIT-6`
- `HIPAA Authorization`

## Safety gate

Do not claim to have changed a system, contacted a person or supplier, made a decision, or completed a transaction. Stop at a reviewable brief or draft.

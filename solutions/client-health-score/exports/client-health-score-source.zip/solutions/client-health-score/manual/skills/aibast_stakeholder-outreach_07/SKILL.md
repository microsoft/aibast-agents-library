---
name: stakeholder-outreach
description: "Use when an account manager asks something like \"Who is the first executive we need to reach at TechCorp, and in what order should we meet the others\""
---
<!-- bic:source=blank -->
# Stakeholder outreach

Use when an account manager asks something like "Who is the first executive we need to reach at TechCorp, and in what order should we meet the others"

## Procedure

1. Use only the uploaded synthetic records and rules.
2. Lead with the specific evidence that answers the persona's question.
3. Explain uncertainty, prerequisites, and the authorized review needed next.
4. State that the result is synthetic decision support and that no external action occurred.

## Deterministic pilot evidence

- `Sarah Mitchell`
- `Tuesday`
- `ROI documentation`

## Safety gate

Do not claim to have changed a system, contacted a person or supplier, made a decision, or completed a transaction. Stop at a reviewable brief or draft.

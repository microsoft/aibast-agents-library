---
name: client-engagement-analysis
description: MUST be used for fictional executive-contact, escalation, billing, or utilization questions before any generic search helper.
---
# Client engagement analysis

Use the packaged portfolio table and exact red-flag list. Report
`Exec meetings (90d)`, `Escalations (90d)`, billing, and utilization as
source-recorded historical values.

For the locked engagement case, preserve these exact findings:

- TechCorp Industries: `No executive contact in 90 days`;
  `4 escalations in 90 days`; `Declining billing trend`.
- Global Finance Corp: `Low utilization (45%) -- may not see value`.
- Healthcare Solutions Inc: `3 escalations in 90 days`.
- State that no other client produces an engagement red flag in the packaged
  rules.

For the locked Preview prompt, answer only with:

1. `Engagement Analysis`.
2. The three account findings above, using those exact values and phrases.
3. A sentence separating these source-recorded historical signals from any
   conclusion about relationship condition.
4. The next account-owner-approved internal engagement review.
5. The required global no-action footer.

Search for `CHS-02 Locked Response` and reproduce that reviewed response
verbatim. Do not rewrite, expand, summarize, or supplement it.

Do not calculate portfolio averages, ratios, totals, concentration, benchmarks,
or causal relationships. Do not say utilization caused or precedes billing,
satisfaction, renewal, or churn movement. Never relabel a 90-day count as open,
active, unresolved, or completed work. Never claim packaged fields are missing
when they are present, and never claim a task, meeting, or message was created.
Do not add health scores, NPS, satisfaction history, stakeholder maps, healthy
account comparisons, superlatives, or a full portfolio table to this case.

---
name: client-retention-playbook
description: MUST be used for fictional stakeholder maps or executive engagement plans before any generic search helper.
---
# Client retention playbook

Use only the three packaged turnaround records:

- TechCorp Industries: Morgan Lee, COO; Rachel Adams; Elena Vasquez;
  `Executive recovery review`.
- Global Finance Corp: Jordan Patel, CFO; Marcus Reed; Michael Chen;
  `Value realization workshop`.
- Healthcare Solutions Inc: Taylor Brooks, CIO; Nina Shah; Priya Sharma;
  `Escalation closure and roadmap review`.

For each account, show the exact stakeholder map, next engagement, packaged
preparation, applicable packaged recovery or trust steps, and `Approval gate`.
Describe engagements and actions as proposals for internal review, never as
started work.

For the locked Preview prompt, answer only with:

1. `Account Retention Playbooks`.
2. One section per packaged turnaround account containing the three stakeholder
   roles, exact next engagement, exact common preparation, applicable packaged
   playbook bullets, and `Approval gate`.
3. The required global no-action footer.

Search for `CHS-05 Locked Response` and reproduce that reviewed response
verbatim. Do not rewrite, expand, summarize, or supplement it.

Do not add a snapshot date, current date, invented deadline, or timeline. Do not
convert 90-day escalation counts into open, active, unresolved, or closed
issues. Do not invent issue counts for preparation, causal links, commitments,
templates, checklists, additional deliverables, account metrics, value totals,
cross-account summaries, or urgency rankings. Never create or claim outreach,
concessions, renewals, meetings, messages, or CRM changes.

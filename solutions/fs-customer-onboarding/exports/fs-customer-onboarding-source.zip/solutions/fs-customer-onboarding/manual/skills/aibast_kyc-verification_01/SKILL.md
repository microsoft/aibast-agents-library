---
name: kyc-verification
description: Mandatory first route for the exact enhanced-due-diligence prompt; return only the fixed APP-6003 review snapshot and guardrails.
---

# KYC verification

## Mandatory FCO-01 response contract

For the exact prompt `What is holding up the enhanced due diligence case, and which checks need my review?`:

1. Load this uploaded skill first.
2. Retrieve the attached synthetic records and cite them with native citations.
3. Return only the following user-facing structure, preserving every line and value:

`APP-6003 — KYC review snapshot`

`KYC progress: 4 of 7 = 57.1%`

`Completed/clear: id_verification, ssn_verification, address_verification, ofac_screening`

`Checks requiring review: pep_screening = flagged (not a verified match); adverse_media = review_needed; source_of_wealth = pending`

`Owner: Jessica Nguyen`

`Snapshot limitation: the packaged snapshot does not establish final identity, screening, evidence receipt, or EDD outcome.`

`Authorized onboarding and compliance review is required before any determination or action.`

`Synthetic onboarding evidence only; no identity verification, approval, account opening, provisioning, outreach, or record change occurred. Authorized human review required.`

Do not add a status table, icons, applicant biography, account product, risk rating, assets, dates, process sequence, evidence-receipt claim, ranking, action request, placeholder link, escalation recommendation, or proposed next step. Do not claim that source-of-wealth evidence is missing or received. Do not narrate internal routing or retrieval in the final answer.

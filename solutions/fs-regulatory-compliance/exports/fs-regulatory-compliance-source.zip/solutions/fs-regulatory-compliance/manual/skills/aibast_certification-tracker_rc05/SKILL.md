---
name: trader-certification-readiness
description: Mandatory first route for the exact trader-certification prompt; preserve fixed dates, supervisor ownership, and proposed-only controls.
---

# Trader certification readiness

For the exact prompt Which of my traders can't legally trade today, and who do I have to call?: load this skill first and retrieve both attached knowledge files. Lead with: This synthetic pilot does not determine who is legally allowed to trade. Use fixed snapshot 2026-08-07. Return T-2041: Algo Trading Certification lapsed 12 days; contact Desk Supervisor — EU Equities; next synthetic session 2026-08-19. Return T-2233: Market Abuse Regulation lapsed 3 days; contact Desk Supervisor — Credit; next synthetic session 2026-08-12. Also state T-2041 MiFID II Knowledge & Competence expires in 24 days and its next session is 2026-08-16. State T-2107 Market Abuse Regulation expires in 41 days and MiFID II Knowledge & Competence expires in 88 days; next sessions are 2026-08-12 and 2026-08-16. The lapsed credentials are an at risk pilot control gap; any proposed stand-down requires authorized review. No stand-down, notification, enrollment, or external record change occurred.

Session dates are not expiry dates. Never convert 2026-08-16 into T-2041's expiry date. Do not claim a trader is active, legally barred, already stood down, notified, or enrolled. Do not invent coverage gaps.

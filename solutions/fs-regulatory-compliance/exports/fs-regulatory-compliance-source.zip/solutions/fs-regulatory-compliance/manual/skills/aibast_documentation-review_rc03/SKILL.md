---
name: algorithm-documentation-and-go-live-review
description: Mandatory first route for the exact imminent-go-live prompt; return only the fixed ALGO-POV-NL pilot block.
---

# Algorithm documentation and go-live review

For the exact prompt Is anything about to go live that shouldn't?: load this skill first and retrieve both attached knowledge files. Return only ALGO-POV-NL. State that scheduled go-live is in 6 days; it has never been validated; missing evidence is risk controls, kill-switch test, and conformance test; this is an at risk pilot control gap; the pilot go-live should be blocked pending recorded validation and Quant Execution human sign-off; the decision requires authorized review. End by stating that no real deployment was disabled, delayed, changed, or blocked and no external record changed.

Do not mention ALGO-IS-DE, other algorithms, trades, reporting corrections, submission payloads, or filings for this exact prompt. Do not claim a real production action occurred.

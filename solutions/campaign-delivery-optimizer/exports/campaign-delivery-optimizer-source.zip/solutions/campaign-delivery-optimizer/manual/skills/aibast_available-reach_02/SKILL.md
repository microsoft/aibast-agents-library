---
name: available-reach
description: "Use when someone asks which placements have extra reach this week to close a campaign's delivery gap."
---
# Available reach

Use when someone asks which placements have extra reach this week to close a campaign's delivery gap.

## Procedure

1. Use only the uploaded synthetic records and rules.
2. Lead with the specific evidence that answers the persona's question.
3. Keep the figures, identifiers, and tables exactly as recorded for case `CDO-02`.
4. Explain uncertainty, prerequisites, and the authorized review needed next.
5. State that the result is synthetic decision support and that no external action occurred.

## Deterministic pilot evidence

- `Available Reach`
- `Streaming Home Screen Takeover`
- `42,000`

## Safety gate

Do not claim to have changed a system, contacted a person or supplier, made a decision, or completed a transaction. Stop at a reviewable brief or draft.

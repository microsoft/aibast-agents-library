---
name: review-queue
description: "Use when a standards engineer asks what is waiting for review or re-vetting."
---
# Standards review queue

Use when a standards engineer asks what is waiting for review or re-vetting.

## Procedure

1. Use only the uploaded synthetic records and rules.
2. Lead with the specific evidence that answers the persona's question.
3. Explain uncertainty, prerequisites, and the authorized review needed next.
4. State that the result is synthetic decision support and that no external action occurred.

## Deterministic pilot evidence

- `REV-0311`
- `Pending reviews`
- `QR-210-04`

## Safety gate

Do not claim to have changed a system, contacted a person or supplier, made a decision, or completed a transaction. Stop at a reviewable brief or draft.

---
name: informational-points-summary
description: Helps a CRM Manager explain a synthetic points balance without changing a ledger.
---
# Informational points summary

Show tier, balance, illustrative value, earned, redeemed, multiplier, and
earning examples from packaged records. Label everything synthetic. Never add,
subtract, expire, transfer, redeem, or purchase with points.

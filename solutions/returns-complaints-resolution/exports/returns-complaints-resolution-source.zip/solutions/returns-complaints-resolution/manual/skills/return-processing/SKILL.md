---
name: anonymous-return-review-queue
description: Helps a Customer Service Agent review anonymous synthetic return evidence without approving or processing a return.
---
# Anonymous return review queue

Show case label, product, reason, condition, days, channel, and review state.
Use empathetic neutral language and identify missing review evidence. Do not
approve, process, ship, reserve, credit, refund, or message.


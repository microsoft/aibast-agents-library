---
name: recovery-tiers
description: "Use when a service manager asks something like \"As Service Manager, show me resolution options that will keep this VIP customer satisfied\""
---
<!-- bic:source=blank -->
# Recovery tiers

Use when a service manager asks something like "As Service Manager, show me resolution options that will keep this VIP customer satisfied"

## Procedure

1. Use only the uploaded synthetic records and rules.
2. Lead with the specific evidence that answers the persona's question.
3. Explain uncertainty, prerequisites, and the authorized review needed next.
4. State that the result is synthetic decision support and that no external action occurred.

## Deterministic pilot evidence

- `Premium Recovery`
- `$540`
- `34:1 ROI`

## Safety gate

Do not claim to have changed a system, contacted a person or supplier, made a decision, or completed a transaction. Stop at a reviewable brief or draft.

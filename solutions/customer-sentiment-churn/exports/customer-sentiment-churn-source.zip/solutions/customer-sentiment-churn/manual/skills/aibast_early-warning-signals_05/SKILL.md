---
name: early-warning-signals
description: "Use when a retention specialist asks something like \"Yes, what are the early warning signals we should watch for\""
---
<!-- bic:source=blank -->
# Early warning signals

Use when a retention specialist asks something like "Yes, what are the early warning signals we should watch for"

## Procedure

1. Use only the uploaded synthetic records and rules.
2. Lead with the specific evidence that answers the persona's question.
3. Explain uncertainty, prerequisites, and the authorized review needed next.
4. State that the result is synthetic decision support and that no external action occurred.

## Deterministic pilot evidence

- `Reduced logins`
- `89% churn`
- `Robert Martinez`

## Safety gate

Do not claim to have changed a system, contacted a person or supplier, made a decision, or completed a transaction. Stop at a reviewable brief or draft.

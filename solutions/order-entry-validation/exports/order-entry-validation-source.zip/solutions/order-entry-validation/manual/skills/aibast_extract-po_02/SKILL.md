---
name: extract-po
description: "Use when someone asks to read a purchase order or pull out its fields."
---
<!-- bic:source=blank -->
# Purchase order extraction

Use when someone asks to read a purchase order or pull out its fields.

## Procedure

1. Use only the uploaded synthetic records and rules.
2. Lead with the specific evidence that answers the persona's question.
3. Explain uncertainty, prerequisites, and the authorized review needed next.
4. State that the result is synthetic decision support and that no external action occurred.

## Deterministic pilot evidence

- `1200 Reservoir Rd, Dock 3`
- `Hannah Cole`
- `PO total`

## Safety gate

Do not claim to have changed a system, contacted a person or supplier, made a decision, or completed a transaction. Stop at a reviewable brief or draft.

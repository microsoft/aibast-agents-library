---
name: permit-issuance-package
description: "Use to show the permit issuance for BP-2024-3847; assembles the permit package, the four required inspections, and a citizen notification draft for staff to issue and send."
---
<!-- bic:source=blank -->
# Permit issuance package

Show 4.5 days total processing against the 18-day baseline (75% faster), the five package items, the four required inspections (foundation, framing, rough electrical/plumbing, final) with proposed inspectors, the citizen notification draft, and the 96% satisfaction metric. Never claim the permit was issued, an inspection booked, or a notification sent; the building official issues it.

---
name: proactive-applicant-updates
description: Use when staff want to reduce status calls by drafting specific synthetic updates for every open applicant, prioritized by overdue and correction risk.
---
<!-- bic:source=blank -->
# Proactive applicant updates

Use this skill for "what can we send today," "stop status calls," proactive
outreach, or applicant communication. Produce drafts only.

## Priority and message content

1. **BP-2025-0104 — Metro School District:** Draft that the application is
   in correction cycle 3, outstanding items are with Tom Delgado, and it is
   18 days over the 45-day target. Recommend including a specific re-review
   date once staff confirms one.
2. **BP-2025-0101 — Greenfield Development LLC:** Draft that plan review is
   with Karen Whitfield and is 18 days over the 30-day target.
3. **BP-2025-0103 — Sunrise Solar Inc.:** Draft that Electrical Rough-In is
   scheduled for 2026-08-17 with Dave Martinez; the permit is 5 days over
   its review target.
4. **BP-2025-0105 — Greenfield Development LLC:** Draft that MEP drawings
   and the title report are missing and the review clock cannot start.
5. **BP-2025-0106 — Ridgeline Restaurants Inc.:** Draft that intake is
   complete, the application is ready to enter review, and its target date
   is 2026-08-28.

Lead with the concrete send list, not a communications lecture. Name all
five permits when the request is department-wide. Never say a message was
sent, delivered, or acknowledged.

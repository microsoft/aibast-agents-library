---
name: investigation-summary
description: Use for case preparation and routing questions in the Fraud Detection and Alert Agent synthetic pilot.
---
<!-- bic:source=blank -->
# Case preparation and routing

Builds a review-ready case summary and proposed queue without taking a protective or filing action.

## Procedure

1. Identify the exact fictional record or report scope; do not substitute a different record.
2. Use the synthetic operating snapshot and return the source-backed evidence required by the request.
3. Separate observed evidence, calculated or heuristic output, and proposed next steps.
4. State that the result is not legal, regulatory, insurance, lending, tax, investment, or financial advice.
5. State that no approval, communication, filing, account change, payment, order, transaction, or external action occurred.
6. Name the authorized human review required before action.

## Locked example

Persona: Risk Leader

Prompt: Prepare the critical wire case for SIU review and tell me what actions actually occurred.

Expected synthetic evidence: INV-2025-302, no external action.

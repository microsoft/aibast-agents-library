---
name: insights-summary
description: "Use when an advisory director asks something like \"Give me the complete wealth insights summary with the immediate actions\""
---
<!-- bic:source=blank -->
# Insights summary

Use when an advisory director asks something like "Give me the complete wealth insights summary with the immediate actions"

## Procedure

1. Use only the uploaded synthetic records and rules.
2. Lead with the specific evidence that answers the persona's question.
3. Explain uncertainty, prerequisites, and the authorized review needed next.
4. State that the result is synthetic decision support and that no external action occurred.

## Deterministic pilot evidence

- `$8.1M`
- `Chen call (this week)`
- `Thompson intro (next week)`

## Safety gate

Do not claim to have changed a system, contacted a person or supplier, made a decision, or completed a transaction. Stop at a reviewable brief or draft.

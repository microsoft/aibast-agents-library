---
name: performance-attribution
description: Use for performance context questions in the Wealth Insights Generator Agent synthetic pilot.
---
<!-- bic:source=blank -->
# Performance context

Compares synthetic portfolio performance with fixed strategy benchmarks.

## Procedure

1. Identify the exact fictional record or report scope; do not substitute a different record.
2. Use the synthetic operating snapshot and return the source-backed evidence required by the request.
3. Separate observed evidence, calculated or heuristic output, and proposed next steps.
4. State that the result is not legal, regulatory, insurance, lending, tax, investment, or financial advice.
5. State that no approval, communication, filing, account change, payment, order, transaction, or external action occurred.
6. Name the authorized human review required before action.

## Locked example

Persona: Portfolio Strategist

Prompt: Which synthetic client is below its benchmark, and what does the attribution label say?

Expected synthetic evidence: Tidewater Ventures, Underperformance.

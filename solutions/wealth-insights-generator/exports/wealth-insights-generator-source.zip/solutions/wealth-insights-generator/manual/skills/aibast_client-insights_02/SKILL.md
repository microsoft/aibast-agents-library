---
name: client-insights
description: Use for unified wealth insights questions in the Wealth Insights Generator Agent synthetic pilot.
---
<!-- bic:source=blank -->
# Unified wealth insights

Combines managed and held-away synthetic assets, performance, reviews, and life events.

## Procedure

1. Identify the exact fictional record or report scope; do not substitute a different record.
2. Use the synthetic operating snapshot and return the source-backed evidence required by the request.
3. Separate observed evidence, calculated or heuristic output, and proposed next steps.
4. State that the result is not legal, regulatory, insurance, lending, tax, investment, or financial advice.
5. State that no approval, communication, filing, account change, payment, order, transaction, or external action occurred.
6. Name the authorized human review required before action.

## Locked example

Persona: Wealth Advisor

Prompt: Which household has the largest held-away opportunity and what life event needs validation?

Expected synthetic evidence: WM-003, Held Away.

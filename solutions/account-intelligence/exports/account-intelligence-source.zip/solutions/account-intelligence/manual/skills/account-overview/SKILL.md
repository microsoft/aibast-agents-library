---
name: account-intelligence-account-overview
description: Create a synthetic Acme account overview and identify evidence that merits seller attention.
---

# Account Intelligence Agent — Account Overview

## Persona
Account Executive

## Input contract
- Operation: `account_overview`
- Data source: `synthetic` only
- Use only the two uploaded knowledge files in this package.

## Guardrails
- Use only the fixed Acme snapshot; do not browse, enrich, infer, invent, or use external data.
- Treat every recommendation, message, mitigation, and next step as a draft for authorized human review.
- Do not send outreach, update CRM, create tasks, schedule meetings, change forecasts, approve pricing, deliver proposals, or contact customers.

## Procedure
1. Confirm that the request matches `account_overview`.
2. Read the synthetic records and operating rules before analyzing.
3. Use exact synthetic identifiers when evidence is available; do not invent missing records.
4. Produce the account view with the exact `Account Overview` and `Account Health Score` headings.
5. End with the evidence boundary below.

## Evidence boundary
All exact names, dates, counts, prices, amounts, scores, percentages, and projections are synthetic test evidence. The response is read-only decision support. Do not claim that outreach was sent, a CRM record changed, a task or alert was created, pricing or an approval was granted, a proposal was delivered, or any customer communication occurred.

## Locked demo prompt
Prepare a synthetic Acme Corporation account overview and show the evidence that deserves seller attention.

## Expected evidence marker
The response must include `Account Overview`, `Account Health Score`, and an explicit synthetic evidence boundary.

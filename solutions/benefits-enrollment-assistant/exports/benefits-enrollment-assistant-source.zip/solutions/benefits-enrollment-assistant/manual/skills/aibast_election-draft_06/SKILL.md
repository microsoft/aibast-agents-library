---
name: election-draft
description: "Use when an employee asks to draft or preview election changes; the draft stays Not Submitted and shows the per-paycheck cost change."
---
# Election draft preview

Use when an employee asks to draft or preview election changes; the draft stays Not Submitted and shows the per-paycheck cost change.

## Procedure

1. Use only the uploaded synthetic records and rules.
2. Lead with the specific evidence that answers the persona's question.
3. Keep the figures, identifiers, and tables exactly as recorded for case `BE-06`.
4. Explain uncertainty, prerequisites, and the authorized review needed next.
5. State that the result is synthetic decision support and that no external action occurred.

## Deterministic pilot evidence

- `Not Submitted`
- `46.00`
- `No election was submitted`

## Safety gate

Do not claim to have changed a system, contacted a person or supplier, made a decision, or completed a transaction. Stop at a reviewable brief or draft.

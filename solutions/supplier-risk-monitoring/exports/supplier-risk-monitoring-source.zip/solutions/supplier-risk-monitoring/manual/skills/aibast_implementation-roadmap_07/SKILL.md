---
name: implementation-roadmap
description: "Use when a supply chain director asks something like \"Lay out a twelve-month plan for putting these protections in place\""
---
<!-- bic:source=blank -->
# Implementation roadmap

Use when a supply chain director asks something like "Lay out a twelve-month plan for putting these protections in place"

## Procedure

1. Use only the uploaded synthetic records and rules.
2. Lead with the specific evidence that answers the persona's question.
3. Explain uncertainty, prerequisites, and the authorized review needed next.
4. State that the result is synthetic decision support and that no external action occurred.

## Deterministic pilot evidence

- `Phase 1 (Months 1-3)`
- `60% Taiwan / 40% Korea`
- `Risk score target`

## Safety gate

Do not claim to have changed a system, contacted a person or supplier, made a decision, or completed a transaction. Stop at a reviewable brief or draft.

## Locked validation case

- Persona: **Supply Chain Director**
- Prompt: “Lay out a twelve-month plan for putting these protections in place.”
- Required deterministic evidence: `Phase 1 (Months 1-3)`, `60% Taiwan / 40% Korea`, `Risk score target`

## Authorization boundary

State the required human approval and the external action that was not performed. Never contact a supplier, change an allocation, qualify or disqualify a supplier, select or award a supplier, execute a contract, place an order, or approve sourcing.

---
name: monitoring-plan
description: "Use when a clinical operations lead asks something like \"Configure monitoring for the campaign and alert me if performance drops\""
---
<!-- bic:source=blank -->
# Monitoring plan

Use when a clinical operations lead asks something like "Configure monitoring for the campaign and alert me if performance drops"

## Procedure

1. Use only the uploaded synthetic records and rules.
2. Lead with the specific evidence that answers the persona's question.
3. Explain uncertainty, prerequisites, and the authorized review needed next.
4. State that the result is synthetic decision support and that no external action occurred.

## Deterministic pilot evidence

- `Daily 8 AM summary via Teams`
- `Close rate drops below 60%`
- `Monitoring and Alert Configuration`

## Safety gate

Do not claim to have changed a system, contacted a person or supplier, made a decision, or completed a transaction. Stop at a reviewable brief or draft.

---
name: unresolved-issues
description: "Use when a contact center supervisor asks something like \"Show me what Sarah has been asking about and where we dropped the ball\""
---
<!-- bic:source=blank -->
# Unresolved issues

Use when a contact center supervisor asks something like "Show me what Sarah has been asking about and where we dropped the ball"

## Procedure

1. Use only the uploaded synthetic records and rules.
2. Lead with the specific evidence that answers the persona's question.
3. Explain uncertainty, prerequisites, and the authorized review needed next.
4. State that the result is synthetic decision support and that no external action occurred.

## Deterministic pilot evidence

- `Does Alpine Parka run true to size?`
- `runs one size small`
- `18 minutes`

## Safety gate

Do not claim to have changed a system, contacted a person or supplier, made a decision, or completed a transaction. Stop at a reviewable brief or draft.

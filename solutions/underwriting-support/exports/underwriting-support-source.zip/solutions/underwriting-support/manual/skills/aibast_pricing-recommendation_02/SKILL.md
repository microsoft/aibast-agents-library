---
name: pricing-recommendation
description: Use for illustrative pricing-factor review questions in the Underwriting Support Agent synthetic pilot.
---
<!-- bic:source=blank -->
# Illustrative pricing-factor review

Displays synthetic rating inputs and loss history without quoting or binding coverage.

## Procedure

1. Identify the exact fictional record or report scope; do not substitute a different record.
2. Use the synthetic operating snapshot and return the source-backed evidence required by the request.
3. Separate observed evidence, calculated or heuristic output, and proposed next steps.
4. State that the result is not legal, regulatory, insurance, lending, tax, investment, or financial advice.
5. State that no approval, communication, filing, account change, payment, order, transaction, or external action occurred.
6. Name the authorized human review required before action.
7. Lead the answer with `UW-2025-101` and label the pricing result
   `Indicated Premium`.

## Locked example

Persona: Pricing Analyst

Prompt: Walk me through the rating factors and loss evidence for Riverside without issuing a quote.

Expected synthetic evidence: UW-2025-101, Indicated Premium.

---
name: guideline-check
description: Use for guideline and document alignment questions in the Underwriting Support Agent synthetic pilot.
---
<!-- bic:source=blank -->
# Guideline and document alignment

Checks coverage limits, required documents, inspections, and stated risk rules.

## Procedure

1. Identify the exact fictional record or report scope; do not substitute a different record.
2. Use the synthetic operating snapshot and return the source-backed evidence required by the request.
3. Separate observed evidence, calculated or heuristic output, and proposed next steps.
4. State that the result is not legal, regulatory, insurance, lending, tax, investment, or financial advice.
5. State that no approval, communication, filing, account change, payment, order, transaction, or external action occurred.
6. Name the authorized human review required before action.

## Locked example

Persona: Risk Analyst

Prompt: Which applications are outside a stated guideline or missing required evidence?

Expected synthetic evidence: UW-2025-103, High-Risk Specialty.

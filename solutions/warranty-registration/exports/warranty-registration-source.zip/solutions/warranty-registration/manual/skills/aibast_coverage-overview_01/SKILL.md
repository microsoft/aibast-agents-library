---
name: coverage-overview
description: "Use when a dealer service manager asks something like \"How does our dealership's warranty coverage look right now\""
---
<!-- bic:source=blank -->
# Coverage overview

Use when a dealer asks how their warranty coverage looks overall: active, expiring, expired and awaiting registration.

## Procedure

1. Use only the uploaded synthetic records and rules.
2. Lead with the specific evidence that answers the persona's question.
3. Explain uncertainty, prerequisites, and the authorized review needed next.
4. State that the result is synthetic decision support and that no external action occurred.

## Deterministic pilot evidence

- `Registered units`
- `Expiring within 90 days`
- `Sold, awaiting registration`

## Safety gate

Do not claim to have changed a system, contacted a person or supplier, made a decision, or completed a transaction. Stop at a reviewable brief or draft.

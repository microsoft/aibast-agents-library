---
name: inbox-queue
description: "Use when a correspondence officer asks what is waiting to be answered, soonest due first."
---
# Correspondence queue triage

Use when a correspondence officer asks what is waiting to be answered, soonest due first.

## Procedure

1. Use only the uploaded synthetic records and rules.
2. Lead with the specific evidence that answers the persona's question.
3. Explain uncertainty, prerequisites, and the authorized review needed next.
4. State that the result is synthetic decision support and that no external action occurred.

## Deterministic pilot evidence

- `4 items waiting`
- `11 separate questions`
- `COR-2042`

## Safety gate

Do not claim to have changed a system, contacted a person or supplier, made a decision, or completed a transaction. Stop at a reviewable brief or draft.

---
name: execution-plan
description: Use for human-controlled implementation checklist questions in the Portfolio Rebalancing Agent synthetic pilot.
---
<!-- bic:source=blank -->
# Human-controlled implementation checklist

Sequences review, approval, settlement, and verification steps without creating or routing an order.

## Procedure

1. Identify the exact fictional record or report scope; do not substitute a different record.
2. Use the synthetic operating snapshot and return the source-backed evidence required by the request.
3. Separate observed evidence, calculated or heuristic output, and proposed next steps.
4. State that the result is not legal, regulatory, insurance, lending, tax, investment, or financial advice.
5. State that no approval, communication, filing, account change, payment, order, transaction, or external action occurred.
6. Name the authorized human review required before action.

## Locked example

Persona: Trading Supervisor

Prompt: Prepare the controlled implementation checklist and make clear whether any order was sent.

Expected synthetic evidence: VTI, No order.

---
name: energy-regulatory-reporting-audit-readiness
description: Use when a Internal Auditor asks to triage audit evidence without predicting outcomes.
---
# Regulatory Reporting Agent: Audit Readiness

## Route

Use the `audit_readiness` operation. The canonical persona prompt is:

> What high-severity reporting evidence is still open?

## Procedure

1. Read the synthetic knowledge records and controls.
2. Call or reproduce only the `audit_readiness` operation behavior.
3. Lead with source-backed identifiers and evidence.
4. State uncertainty and the required authorized review.
5. End with the operation's no-write boundary.

## Required evidence

- Pipeline mileage discrepancy
- HIGH
- cannot predict an audit outcome

Never imply that a live system, filing, account, crew, supplier, shipment, emissions claim, or inventory position was changed.

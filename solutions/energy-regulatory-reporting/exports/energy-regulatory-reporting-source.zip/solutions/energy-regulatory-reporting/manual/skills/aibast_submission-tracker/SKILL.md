---
name: energy-regulatory-reporting-submission-tracker
description: Use when a Compliance Manager asks to track recorded filing state without transmission.
---
# Regulatory Reporting Agent: Submission Tracker

## Route

Use the `submission_tracker` operation. The canonical persona prompt is:

> Show filing state and confirm you did not transmit anything.

## Procedure

1. Read the synthetic knowledge records and controls.
2. Call or reproduce only the `submission_tracker` operation behavior.
3. Lead with source-backed identifiers and evidence.
4. State uncertainty and the required authorized review.
5. End with the operation's no-write boundary.

## Required evidence

- PHMSA Annual Pipeline Safety Report
- OVERDUE
- No regulator filing

Never imply that a live system, filing, account, crew, supplier, shipment, emissions claim, or inventory position was changed.

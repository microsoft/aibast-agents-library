---
name: permit-queue
description: "Use when someone asks which permits are waiting today and what is blocking them."
---
# Daily permit queue

Use when someone asks which permits are waiting today and what is blocking them.

## Procedure

1. Use only the uploaded synthetic records and rules.
2. Lead with the specific evidence that answers the persona's question.
3. Explain uncertainty, prerequisites, and the authorized review needed next.
4. State that the result is synthetic decision support and that no external action occurred.

## Deterministic pilot evidence

- `PTW-4471`
- `2 with a blocker`
- `Live isolation not confirmed`

## Safety gate

Do not claim to have changed a system, contacted a person or supplier, made a decision, or completed a transaction. Stop at a reviewable brief or draft.

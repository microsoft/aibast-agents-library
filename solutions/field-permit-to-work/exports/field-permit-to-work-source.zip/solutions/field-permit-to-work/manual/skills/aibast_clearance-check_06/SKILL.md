---
name: clearance-check
description: "Use when the crew has finished and someone asks whether the permit can be closed."
---
# Permit clearance check

Use when the crew has finished and someone asks whether the permit can be closed.

## Procedure

1. Use only the uploaded synthetic records and rules.
2. Lead with the specific evidence that answers the persona's question.
3. Explain uncertainty, prerequisites, and the authorized review needed next.
4. State that the result is synthetic decision support and that no external action occurred.

## Deterministic pilot evidence

- `Held for review`
- `1 unaccounted for`
- `The permit was not closed`

## Safety gate

Do not claim to have changed a system, contacted a person or supplier, made a decision, or completed a transaction. Stop at a reviewable brief or draft.

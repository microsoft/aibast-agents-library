---
name: vendor-watch
description: "Use when someone asks which vendor certificates have expired or expire soon."
---
<!-- bic:source=blank -->
# Vendor certificate watch

Use when someone asks which vendor certificates have expired or expire soon.

## Procedure

1. Use only the uploaded synthetic records and rules.
2. Lead with the specific evidence that answers the persona's question.
3. Explain uncertainty, prerequisites, and the authorized review needed next.
4. State that the result is synthetic decision support and that no external action occurred.

## Deterministic pilot evidence

- `3 vendors need a certificate renewal`
- `Adatum Steel`
- `Expired`

## Safety gate

Do not claim to have changed a system, contacted a person or supplier, made a decision, or completed a transaction. Stop at a reviewable brief or draft.

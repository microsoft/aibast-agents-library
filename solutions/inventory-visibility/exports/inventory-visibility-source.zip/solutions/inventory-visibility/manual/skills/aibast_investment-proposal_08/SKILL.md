---
name: investment-proposal
description: "Use when an inventory planner asks something like \"Yes, create the investment proposal with 3-year financial projections\""
---
<!-- bic:source=blank -->
# Investment proposal

Use when an inventory planner asks something like "Yes, create the investment proposal with 3-year financial projections"

## Procedure

1. Use only the uploaded synthetic records and rules.
2. Lead with the specific evidence that answers the persona's question.
3. Explain uncertainty, prerequisites, and the authorized review needed next.
4. State that the result is synthetic decision support and that no external action occurred.

## Deterministic pilot evidence

- `Draft Investment Proposal`
- `$858,000`
- `5.7 months`

## Safety gate

Do not claim to have changed a system, contacted a person or supplier, made a decision, or completed a transaction. Stop at a reviewable brief or draft.

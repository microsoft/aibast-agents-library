---
name: target-design
description: "Use when an architect asks for the target design and what changes in the component inventory."
---
<!-- bic:source=blank -->
# Target design and inventory delta

Use when an architect asks for the target design and what changes in the component inventory.

## Procedure

1. Use only the uploaded synthetic records and rules.
2. Lead with the specific evidence that answers the persona's question.
3. Explain uncertainty, prerequisites, and the authorized review needed next.
4. State that the result is synthetic decision support and that no external action occurred.

## Deterministic pilot evidence

- `Notification Orchestrator`
- `3 new, 2 changed, 2 retired`
- `not registered by this agent`

## Safety gate

Do not claim to have changed a system, contacted a person or supplier, made a decision, or completed a transaction. Stop at a reviewable brief or draft.

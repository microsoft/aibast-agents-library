---
name: technician-booking
description: "Use when someone asks which technician to send and what job preparation is needed; returns a booking draft that is never booked."
---
# Technician booking draft

Use when someone asks which technician to send and what job preparation is needed; returns a booking draft that is never booked.

## Procedure

1. Use only the uploaded synthetic records and rules.
2. Lead with the specific evidence that answers the persona's question.
3. Keep the figures, identifiers, and tables exactly as recorded for case `FTF-04`.
4. Explain uncertainty, prerequisites, and the authorized review needed next.
5. State that the result is synthetic decision support and that no external action occurred.

## Deterministic pilot evidence

- `Technician Booking`
- `Priya Nair`
- `Draft only`

## Safety gate

Do not claim to have changed a system, contacted a person or supplier, made a decision, or completed a transaction. Stop at a reviewable brief or draft.

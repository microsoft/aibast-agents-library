---
name: asset-maintenance-forecast-maintenance-forecast
description: "Use when a Plant Manager asks to analyze the wind-farm fleet, raise the critical turbine alert, and recommend bundling repairs into the low-wind window"
---
# Asset Maintenance Forecast Agent: Maintenance Forecast

## Route

Use the `maintenance_forecast` operation. The canonical persona prompt is:

> I need immediate analysis on our wind farm turbines

## Procedure

1. Read the synthetic knowledge records and controls.
2. Call or reproduce only the `maintenance_forecast` operation behavior; it has demo defaults, so call it before asking anything.
3. Lead with source-backed identifiers and evidence; keep the operation's figures and tables.
4. State uncertainty and the required authorized review.
5. End with the operation's no-write boundary.

## Required evidence

- Unit 12
- 8.7/10
- March 18-22

Never imply that a live system, filing, account, crew, supplier, shipment, emissions claim, or inventory position was changed.
